<?php
echo "hello";
exit;
?>